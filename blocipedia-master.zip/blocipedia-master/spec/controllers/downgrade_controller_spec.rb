require 'rails_helper'

RSpec.describe DowngradeController, type: :controller do

end
