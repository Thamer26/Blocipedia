require 'rails_helper'

RSpec.describe CollaboratorsController, type: :controller do

end
