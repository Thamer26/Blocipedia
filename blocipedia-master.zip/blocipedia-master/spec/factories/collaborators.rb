FactoryGirl.define do
  factory :collaborator do
    user nil
    wiki nil
  end
end
