require 'rails_helper'

RSpec.describe Wiki, type: :model do
end